
[1,2,3].forEach((number)=>{
    console.log('number is '+number);
});
